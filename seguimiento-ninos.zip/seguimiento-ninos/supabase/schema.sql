-- Ejecutar en Supabase > SQL Editor
create table public.ninos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  cupo text,
  nombre text not null default '',
  sexo text not null default '' check (sexo in ('', 'f', 'm')),
  modulo text,
  fecha_nacimiento date,
  proxima_visita date,
  hora_visita time,
  creado timestamptz not null default now()
);
create table public.sesiones (
  id uuid primary key default gen_random_uuid(),
  nino_id uuid not null references public.ninos on delete cascade,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  fecha date not null,
  area text not null,
  nota text not null
);
create table public.configuracion (
  user_id uuid primary key default auth.uid() references auth.users on delete cascade,
  datos jsonb not null default '{}',
  actualizado timestamptz not null default now()
);
create index on public.sesiones (nino_id);

alter table public.ninos enable row level security;
alter table public.sesiones enable row level security;
alter table public.configuracion enable row level security;

create policy "ninos: solo el dueño" on public.ninos for all
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "sesiones: solo el dueño" on public.sesiones for all
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy "configuracion: solo el dueño" on public.configuracion for all
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Si la tabla "ninos" ya existía antes de agregar cupo/módulo/hora de visita, ejecuta:
-- alter table public.ninos add column if not exists cupo text;
-- alter table public.ninos add column if not exists modulo text;
-- alter table public.ninos add column if not exists hora_visita time;
